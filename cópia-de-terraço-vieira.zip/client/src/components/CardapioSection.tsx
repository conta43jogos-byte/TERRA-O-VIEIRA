/**
 * Terraço Vieira — Cardápio Section
 * Design: Nordestino Premium — warm cream bg, tab navigation, card grid with WhatsApp order
 */
import { useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { trpc } from '@/lib/trpc';

type MenuItem = {
  name: string;
  desc: string;
  price: string;
  waText: string;
};

type Category = {
  id: string;
  label: string;
  emoji: string;
  items: MenuItem[];
};

const categories: Category[] = [
  {
    id: 'comidas',
    label: 'Comidas & Petiscos',
    emoji: '🍲',
    items: [
      { name: 'Panelada', desc: 'Prato típico nordestino, servido bem quentinho.', price: 'R$ 10,00', waText: 'Panelada - R$ 10,00' },
      { name: 'Feijoada c/ Arroz', desc: 'Feijoada completa com arroz branco.', price: 'R$ 20,00', waText: 'Feijoada c/ Arroz - R$ 20,00' },
      { name: 'Filé c/ Fritas', desc: 'Filé suculento acompanhado de batata frita.', price: 'R$ 35,00', waText: 'Filé c/ Fritas - R$ 35,00' },
      { name: 'Calabresa c/ Fritas', desc: 'Calabresa acebolada com batata frita.', price: 'R$ 35,00', waText: 'Calabresa c/ Fritas - R$ 35,00' },
      { name: 'Macaxeira c/ Carne de Sol', desc: 'Macaxeira com carne de sol.', price: 'R$ 35,00', waText: 'Macaxeira c/ Carne de Sol - R$ 35,00' },
      { name: 'Carne de Sol c/ Fritas', desc: 'Carne de sol com batata frita.', price: 'R$ 35,00', waText: 'Carne de Sol c/ Fritas - R$ 35,00' },
    ],
  },
  {
    id: 'copoes',
    label: 'Copões',
    emoji: '🥤',
    items: [
      { name: 'Copão Tropical', desc: 'Bebida refrescante com frutas tropicais.', price: 'R$ 15,00', waText: 'Copão Tropical - R$ 15,00' },
      { name: 'Copão Especial', desc: 'Nossa mistura exclusiva da casa.', price: 'R$ 18,00', waText: 'Copão Especial - R$ 18,00' },
    ],
  },
  {
    id: 'combos',
    label: 'Combos',
    emoji: '🍾',
    items: [
      { name: 'Combo Mansão Maromba', desc: 'Bebidas e drinks da linha exclusiva Mansão Maromba.', price: 'R$ 25,00', waText: 'Combo Mansão Maromba - R$ 25,00' },
    ],
  },
  {
    id: 'cervejas',
    label: 'Cervejas',
    emoji: '🍻',
    items: [
      { name: 'Cerveja Long Neck', desc: 'Estupidamente gelada, do jeito que você gosta.', price: 'R$ 12,00', waText: 'Cerveja Long Neck - R$ 12,00' },
      { name: 'Cerveja Lata', desc: 'Gelada na temperatura certa.', price: 'R$ 8,00', waText: 'Cerveja Lata - R$ 8,00' },
    ],
  },
  {
    id: 'sem-alcool',
    label: 'Sem Álcool',
    emoji: '🥤',
    items: [
      { name: 'Refrigerante', desc: 'Diversas marcas e sabores.', price: 'R$ 5,00', waText: 'Refrigerante - R$ 5,00' },
      { name: 'Água', desc: 'Com ou sem gás.', price: 'R$ 3,00', waText: 'Água - R$ 3,00' },
      { name: 'Suco Natural', desc: 'Frutas da estação.', price: 'R$ 8,00', waText: 'Suco Natural - R$ 8,00' },
    ],
  },
];

export default function CardapioSection() {
  const [activeTab, setActiveTab] = useState('comidas');
  const menuQuery = trpc.menu.items.useQuery();
  const settingsQuery = trpc.settings.all.useQuery();
  const storedItems = menuQuery.data ?? [];
  const hasStoredItems = storedItems.length > 0;
  const visibleCategories = hasStoredItems
    ? categories
        .map((category) => ({
          ...category,
          items: storedItems
            .filter((item) => item.category === category.id)
            .map((item) => ({
              name: item.name,
              desc: item.description || 'Consulte os detalhes deste item no Terraço Vieira.',
              price: item.price,
              waText: `${item.name} - ${item.price}`,
            })),
        }))
        .filter((category) => category.items.length > 0)
    : categories;
  const resolvedTab = visibleCategories.some((category) => category.id === activeTab)
    ? activeTab
    : visibleCategories[0]?.id || 'comidas';
  const active = visibleCategories.find((category) => category.id === resolvedTab) || visibleCategories[0]!;
  const whatsappNumber = settingsQuery.data?.whatsapp_number || '558681484273';

  return (
    <section id="cardapio" style={{
      background: '#1a0f00',
      padding: '6rem 0',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Subtle warm texture */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `url('/manus-storage/terraco-petiscos_4235b4dd.jpg')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        opacity: 0.08,
      }} />
      <div style={{
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(180deg, rgba(26,15,0,0.97) 0%, rgba(26,15,0,0.92) 100%)',
      }} />

      <div className="container" style={{ position: 'relative', zIndex: 1 }}>
        {/* Header */}
        <div style={{ marginBottom: '3rem' }}>
          <p className="section-label" style={{ marginBottom: '0.75rem' }}>Nosso Cardápio</p>
          <h2 style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontWeight: 700,
            fontSize: 'clamp(2rem, 4vw, 3rem)',
            color: '#f5f0e8',
            lineHeight: 1.2,
            marginBottom: '0.5rem',
            maxWidth: '600px',
          }}>
            Sabores que acompanham<br />a sua resenha
          </h2>
        </div>

        {/* Tabs */}
        <div style={{
          display: 'flex',
          gap: '0.5rem',
          flexWrap: 'wrap',
          marginBottom: '2.5rem',
        }}>
          {visibleCategories.map((cat) => (
            <button key={cat.id}
              onClick={() => setActiveTab(cat.id)}
              style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 700,
                fontSize: '0.875rem',
                padding: '0.6rem 1.25rem',
                borderRadius: '100px',
                border: '2px solid',
                borderColor: resolvedTab === cat.id ? '#e8820c' : 'rgba(245,240,232,0.15)',
                background: resolvedTab === cat.id ? '#e8820c' : 'transparent',
                color: resolvedTab === cat.id ? '#0d0d0d' : 'rgba(245,240,232,0.7)',
                transition: 'all 150ms ease',
                cursor: 'pointer',
              }}
            >
              {cat.emoji} {cat.label}
            </button>
          ))}
        </div>

        {/* Items grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
          gap: '1.25rem',
          marginBottom: '2rem',
        }}>
          {active.items.map((item) => (
            <div key={item.name} style={{
              background: 'rgba(255,255,255,0.05)',
              borderRadius: '10px',
              padding: '1.5rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.5rem',
              border: '1px solid rgba(245,240,232,0.08)',
              borderLeft: '3px solid #e8820c',
              transition: 'background 200ms ease, border-color 200ms ease',
            }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'rgba(232,130,12,0.08)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.05)';
              }}
            >
              <h3 style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 800,
                fontSize: '1rem',
                color: '#f5f0e8',
              }}>{item.name}</h3>
              <p style={{
                fontFamily: "'Nunito', sans-serif",
                fontSize: '0.85rem',
                color: 'rgba(245,240,232,0.55)',
                lineHeight: 1.5,
                flex: 1,
              }}>{item.desc}</p>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.5rem' }}>
                <span style={{
                  fontFamily: "'Nunito', sans-serif",
                  fontWeight: 800,
                  fontSize: '1.1rem',
                  color: '#e8820c',
                }}>{item.price}</span>
                <a href={`https://wa.me/${whatsappNumber.replace(/\D/g, '')}?text=Olá!%20Quero%20pedir%3A%20${encodeURIComponent(item.waText)}`}
                  target="_blank" rel="noopener noreferrer"
                  className="btn-amber"
                  style={{ padding: '0.45rem 1rem', fontSize: '0.8rem' }}
                >
                  <MessageCircle size={14} />
                  Pedir
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <p style={{
          fontFamily: "'Nunito', sans-serif",
          fontSize: '0.8rem',
          color: 'rgba(245,240,232,0.35)',
          marginTop: '1rem',
        }}>
          ⚠️ Preços sujeitos a alteração. Consulte disponibilidade no local.
        </p>
      </div>
    </section>
  );
}
