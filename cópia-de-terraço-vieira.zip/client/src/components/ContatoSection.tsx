/**
 * Terraço Vieira — Contato Section
 * Design: Nordestino Premium — dark bg, info cards, WhatsApp CTA
 */
import { MapPin, Phone, Clock, Instagram, MessageCircle } from 'lucide-react';
import { trpc } from '@/lib/trpc';

type ContactCard = {
  icon: typeof MapPin;
  title: string;
  lines: string[];
  link: string | null;
  linkLabel: string | null;
};

export default function ContatoSection() {
  const settingsQuery = trpc.settings.all.useQuery();
  const settings = settingsQuery.data ?? {};
  const whatsapp = (settings.whatsapp_number || '558681484273').replace(/\D/g, '');
  const instagram = settings.instagram_url || 'https://instagram.com/terraco_vieira';
  const address = settings.address || 'Avenida Castelo Branco, Nº 1290, Inhuma - Piauí';
  const weekdays = settings.hours_weekdays || 'Segunda a sexta, 16h às 23h';
  const weekend = settings.hours_weekend || 'Consulte a programação';
  const contactCards: ContactCard[] = [
    {
      icon: MapPin,
      title: 'Endereço',
      lines: [address],
      link: `https://maps.google.com/?q=${encodeURIComponent(address)}`,
      linkLabel: 'Ver no mapa',
    },
    {
      icon: Phone,
      title: 'WhatsApp',
      lines: [`+${whatsapp.slice(0, 2)} (${whatsapp.slice(2, 4)}) ${whatsapp.slice(4, 8)}-${whatsapp.slice(8)}`],
      link: `https://wa.me/${whatsapp}?text=Olá!%20Vim%20pelo%20site%20do%20Terraço%20Vieira.`,
      linkLabel: 'Falar agora',
    },
    {
      icon: Clock,
      title: 'Horários',
      lines: [weekdays, weekend],
      link: null,
      linkLabel: null,
    },
    {
      icon: Instagram,
      title: 'Instagram',
      lines: [instagram.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '')],
      link: instagram,
      linkLabel: 'Acompanhar',
    },
  ];

  return (
    <section id="contato" style={{ background: '#0d0d0d', padding: '6rem 0' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <p className="section-label" style={{ marginBottom: '0.75rem' }}>Contato & Localização</p>
          <h2 style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontWeight: 700,
            fontSize: 'clamp(2rem, 4vw, 3rem)',
            color: '#f5f0e8',
            lineHeight: 1.2,
          }}>
            Venha nos visitar
          </h2>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '1.25rem',
          marginBottom: '3rem',
        }}>
          {contactCards.map(({ icon: Icon, title, lines, link, linkLabel }) => (
            <div key={title} style={{
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '12px',
              padding: '1.75rem',
              transition: 'border-color 200ms ease, background 200ms ease',
            }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = 'rgba(232,130,12,0.4)';
                (e.currentTarget as HTMLElement).style.background = 'rgba(232,130,12,0.05)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = 'rgba(255,255,255,0.08)';
                (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
              }}
            >
              <div style={{ width: '44px', height: '44px', borderRadius: '10px', background: 'rgba(232,130,12,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                <Icon size={20} style={{ color: '#e8820c' }} />
              </div>
              <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: '0.75rem', color: '#e8820c', letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>{title}</p>
              {lines.map((line, i) => <p key={i} style={{ fontFamily: "'Nunito', sans-serif", fontSize: '0.9rem', color: 'rgba(245,240,232,0.8)', lineHeight: 1.6 }}>{line}</p>)}
              {link && linkLabel && <a href={link} target="_blank" rel="noopener noreferrer" style={{ display: 'inline-block', marginTop: '0.75rem', fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: '0.85rem', color: '#e8820c', textDecoration: 'none', borderBottom: '1px solid rgba(232,130,12,0.4)', paddingBottom: '1px', transition: 'border-color 150ms ease' }}>{linkLabel} →</a>}
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center' }}>
          <a href={`https://wa.me/${whatsapp}?text=Olá!%20Vim%20pelo%20site%20do%20Terraço%20Vieira%20e%20gostaria%20de%20fazer%20uma%20reserva.`} target="_blank" rel="noopener noreferrer" className="btn-amber" style={{ fontSize: '1rem', padding: '0.9rem 2.5rem' }}>
            <MessageCircle size={20} />
            Reservar Mesa pelo WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
