/**
 * Terraço Vieira — Navbar
 * Design: Nordestino Premium — dark background, amber accent, Nunito font
 * Behavior: transparent on hero, solid dark on scroll
 */
import { useState, useEffect } from 'react';
import { Menu, X, MessageCircle, Instagram } from 'lucide-react';

const navLinks = [
  { label: 'Início', href: '#inicio' },
  { label: 'Sobre', href: '#sobre' },
  { label: 'Cardápio', href: '#cardapio' },
  { label: 'Galeria Imersiva', href: '/galeria-imersiva', external: true },
  { label: 'Contato', href: '#contato' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (href: string, external?: boolean) => {
    setMenuOpen(false);
    if (external) {
      window.location.href = href;
      return;
    }
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 50,
        transition: 'background 300ms ease, box-shadow 300ms ease',
        background: scrolled ? 'rgba(13,13,13,0.97)' : 'transparent',
        boxShadow: scrolled ? '0 2px 24px rgba(0,0,0,0.4)' : 'none',
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
      }}
    >
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '68px' }}>
        {/* Logo + Wordmark */}
        <a href="#inicio" onClick={(e) => { e.preventDefault(); handleNav('#inicio'); }}
          style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            border: '2px solid rgba(232,130,12,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden',
            background: 'rgba(232,130,12,0.1)',
            flexShrink: 0,
          }}>
            <img src="/manus-storage/terraco-logo_f16cb1b2.png" alt="Terraço Vieira" style={{ width: '32px', height: '32px', objectFit: 'contain' }} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 900, fontSize: '0.95rem', color: '#f5f0e8', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
              TERRAÇO
            </span>
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 900, fontSize: '0.95rem', color: '#e8820c', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
              VIEIRA
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '2rem' }} className="hidden md:flex">
          {navLinks.map((link) => (
            <a key={link.href} href={link.href}
              onClick={(e) => { e.preventDefault(); handleNav(link.href, (link as any).external); }}
              style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 600,
                fontSize: '0.875rem',
                color: '#f5f0e8',
                textDecoration: 'none',
                letterSpacing: '0.05em',
                transition: 'color 150ms ease',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.color = '#e8820c')}
              onMouseLeave={(e) => (e.currentTarget.style.color = '#f5f0e8')}
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <a href="https://instagram.com/terraco_vieira" target="_blank" rel="noopener noreferrer"
            style={{ color: '#f5f0e8', transition: 'color 150ms ease', display: 'flex' }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#e8820c')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#f5f0e8')}
            aria-label="Instagram"
          >
            <Instagram size={20} />
          </a>
          <a href="https://wa.me/558681484273?text=Olá!%20Vim%20pelo%20site%20do%20Terraço%20Vieira."
            target="_blank" rel="noopener noreferrer"
            className="btn-amber hidden md:inline-flex"
            style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}
          >
            <MessageCircle size={16} />
            WhatsApp
          </a>
          <button
            className="md:hidden"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ background: 'none', border: 'none', color: '#f5f0e8', padding: '4px' }}
            aria-label="Menu"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div style={{
          background: 'rgba(13,13,13,0.98)',
          borderTop: '1px solid rgba(232,130,12,0.2)',
          padding: '1rem 0',
        }}>
          {navLinks.map((link) => (
            <a key={link.href} href={link.href}
              onClick={(e) => { e.preventDefault(); handleNav(link.href, (link as any).external); }}
              style={{
                display: 'block',
                padding: '0.75rem 1.5rem',
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 600,
                color: '#f5f0e8',
                textDecoration: 'none',
                fontSize: '1rem',
                borderBottom: '1px solid rgba(255,255,255,0.04)',
              }}
            >
              {link.label}
            </a>
          ))}
          <div style={{ padding: '0.75rem 1.5rem' }}>
            <a href="https://wa.me/558681484273?text=Olá!%20Vim%20pelo%20site%20do%20Terraço%20Vieira."
              target="_blank" rel="noopener noreferrer"
              className="btn-amber"
              style={{ width: '100%', justifyContent: 'center' }}
            >
              <MessageCircle size={16} />
              WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
