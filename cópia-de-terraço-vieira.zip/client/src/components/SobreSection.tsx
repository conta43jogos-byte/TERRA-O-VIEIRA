/**
 * Terraço Vieira — Sobre Section
 * Design: Nordestino Premium — warm rustic paper texture, asymmetric layout, amber rules
 */
import { Beer, UtensilsCrossed, Tv2, Music } from 'lucide-react';

const features = [
  {
    icon: Beer,
    title: 'Bebidas Geladíssimas',
    desc: 'Cervejas no ponto certo, drinks, copões e combos para todos os gostos.',
  },
  {
    icon: UtensilsCrossed,
    title: 'Petiscos e Comidas Típicas',
    desc: 'Pratos deliciosos feitos na hora para acompanhar a sua resenha.',
  },
  {
    icon: Tv2,
    title: 'Transmissão de Jogos',
    desc: 'Venha torcer pelo seu time do coração com a melhor estrutura de som e imagem da região.',
  },
  {
    icon: Music,
    title: 'Música Boa',
    desc: 'Som ambiente de qualidade para embalar os seus momentos de lazer.',
  },
];

export default function SobreSection() {
  return (
    <section id="sobre" style={{
      background: '#f5ede0',
      padding: '6rem 0',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Subtle texture overlay */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='400' height='400' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E")`,
        pointerEvents: 'none',
      }} />

      {/* Amber vertical rule — left accent */}
      <div style={{
        position: 'absolute',
        left: 0,
        top: '10%',
        bottom: '10%',
        width: '4px',
        background: 'linear-gradient(to bottom, transparent, #e8820c 20%, #e8820c 80%, transparent)',
        opacity: 0.7,
      }} />

      <div className="container" style={{ position: 'relative' }}>
        {/* Asymmetric header — left aligned */}
        <div style={{ marginBottom: '3.5rem', maxWidth: '560px' }}>
          <p className="section-label" style={{ marginBottom: '0.75rem' }}>Quem Somos</p>
          <h2 style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontWeight: 700,
            fontSize: 'clamp(2.2rem, 4.5vw, 3.2rem)',
            color: '#1a0f00',
            lineHeight: 1.15,
            marginBottom: '1.25rem',
          }}>
            Um ambiente acolhedor<br />
            <span style={{ color: '#e8820c' }}>ao ar livre</span>
          </h2>
          <p style={{
            fontFamily: "'Nunito', sans-serif",
            fontSize: '1.05rem',
            color: '#5a3e1b',
            lineHeight: 1.75,
          }}>
            Criamos um espaço para você colecionar bons momentos com quem gosta. Mais que um bar, um ponto de encontro em Inhuma.
          </p>
        </div>

        {/* Feature cards — 2x2 grid with rustic warm style */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
          gap: '1.25rem',
        }}>
          {features.map(({ icon: Icon, title, desc }, i) => (
            <div key={title} style={{
              background: i % 2 === 0 ? '#fff8f0' : '#fffaf5',
              borderRadius: '10px',
              padding: '1.75rem',
              borderLeft: '3px solid #e8820c',
              boxShadow: '0 2px 12px rgba(139,69,19,0.08)',
              transition: 'transform 200ms ease, box-shadow 200ms ease',
            }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.transform = 'translateY(-3px)';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 10px 28px rgba(139,69,19,0.15)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 2px 12px rgba(139,69,19,0.08)';
              }}
            >
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '10px',
                background: 'rgba(232,130,12,0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '1rem',
              }}>
                <Icon size={22} style={{ color: '#e8820c' }} />
              </div>
              <h3 style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 800,
                fontSize: '1rem',
                color: '#1a0f00',
                marginBottom: '0.4rem',
              }}>{title}</h3>
              <p style={{
                fontFamily: "'Nunito', sans-serif",
                fontSize: '0.875rem',
                color: '#6b4c2a',
                lineHeight: 1.65,
              }}>{desc}</p>
            </div>
          ))}
        </div>

        {/* Ambient image strip — right side */}
        <div style={{
          marginTop: '3rem',
          borderRadius: '12px',
          overflow: 'hidden',
          height: '220px',
          position: 'relative',
        }}>
          <img
            src="/manus-storage/terraco-ambiente_aeafeaec.jpg"
            alt="Ambiente do Terraço Vieira"
            style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 40%' }}
          />
          <div style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to right, rgba(245,237,224,0.9) 0%, rgba(245,237,224,0.2) 40%, transparent 70%)',
          }} />
          <div style={{ position: 'absolute', left: '2rem', top: '50%', transform: 'translateY(-50%)' }}>
            <p style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontWeight: 700,
              fontSize: 'clamp(1.2rem, 2.5vw, 1.8rem)',
              color: '#1a0f00',
              lineHeight: 1.3,
            }}>Mais que um bar —<br />
              <span style={{ color: '#e8820c' }}>uma experiência.</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
