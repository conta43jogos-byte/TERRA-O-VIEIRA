import { useAuth } from '@/_core/hooks/useAuth';
import { startLogin } from '@/const';
import DashboardLayout from '@/components/DashboardLayout';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, ImagePlus, Pencil, Plus, Save, Trash2, Upload, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';

type Tab = 'galeria' | 'cardapio' | 'configuracoes';

type GalleryForm = {
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  displayOrder: string;
  isActive: boolean;
};

type MenuForm = {
  name: string;
  description: string;
  price: string;
  category: string;
  displayOrder: string;
  isActive: boolean;
};

const emptyGalleryForm: GalleryForm = {
  title: '',
  description: '',
  imageUrl: '',
  category: 'ambiente',
  displayOrder: '0',
  isActive: true,
};

const emptyMenuForm: MenuForm = {
  name: '',
  description: '',
  price: '',
  category: 'comidas',
  displayOrder: '0',
  isActive: true,
};

const galleryCategories = [
  { value: 'ambiente', label: 'Ambiente' },
  { value: 'gastronomia', label: 'Gastronomia' },
  { value: 'drinks', label: 'Drinks' },
  { value: 'eventos', label: 'Eventos' },
];

const menuCategories = [
  { value: 'comidas', label: 'Comidas' },
  { value: 'copoes', label: 'Copões' },
  { value: 'combos', label: 'Combos' },
  { value: 'cervejas', label: 'Cervejas' },
  { value: 'sem-alcool', label: 'Sem álcool' },
];

const defaultSettings = {
  business_name: 'Terraço Vieira',
  address: 'Inhuma, Piauí',
  whatsapp_number: '558681484273',
  instagram_url: 'https://instagram.com/terracovieira',
  hours_weekdays: 'Segunda a sexta, 16h às 23h',
  hours_weekend: 'Consulte a programação',
};

export default function Admin() {
  const { user, isAuthenticated, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('galeria');

  if (loading) {
    return <FullPageLoader label="Carregando painel…" />;
  }

  if (!isAuthenticated || user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-stone-950 text-stone-100 flex items-center justify-center p-6">
        <Card className="w-full max-w-md border-amber-500/20 bg-stone-900 text-stone-100">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Acesso restrito</CardTitle>
            <CardDescription className="text-stone-400">Apenas administradores podem gerenciar o Terraço Vieira.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full bg-amber-500 text-stone-950 hover:bg-amber-400" onClick={() => startLogin()}>
              Fazer login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="min-h-[calc(100vh-2rem)] bg-stone-50 -m-4 p-4 md:p-8 text-stone-900">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-[0.22em] text-amber-700">Terraço Vieira</p>
              <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">Painel de conteúdo</h1>
              <p className="mt-2 text-stone-500">Atualize o site sem editar código ou banco de dados.</p>
            </div>
            <div className="rounded-full border border-stone-200 bg-white px-4 py-2 text-sm text-stone-600 shadow-sm">
              Olá, {user.name || 'administrador'}
            </div>
          </div>

          <div className="mb-6 flex gap-1 overflow-x-auto rounded-xl border border-stone-200 bg-white p-1 shadow-sm">
            {([
              ['galeria', 'Galeria'],
              ['cardapio', 'Cardápio'],
              ['configuracoes', 'Configurações'],
            ] as const).map(([tab, label]) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`whitespace-nowrap rounded-lg px-4 py-2.5 text-sm font-medium transition-colors ${
                  activeTab === tab ? 'bg-stone-900 text-white' : 'text-stone-500 hover:bg-stone-100 hover:text-stone-900'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {activeTab === 'galeria' && <GaleriaTab />}
          {activeTab === 'cardapio' && <CardapioTab />}
          {activeTab === 'configuracoes' && <ConfiguracoesTab />}
        </div>
      </div>
    </DashboardLayout>
  );
}

function FullPageLoader({ label }: { label: string }) {
  return (
    <div className="flex min-h-screen items-center justify-center gap-3 bg-stone-950 text-stone-200">
      <Loader2 className="h-5 w-5 animate-spin text-amber-400" />
      <span>{label}</span>
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="mb-1.5 block text-sm font-medium text-stone-700">{children}</label>;
}

function FormActions({ onCancel, pending }: { onCancel: () => void; pending: boolean }) {
  return (
    <div className="flex flex-wrap justify-end gap-2 border-t border-stone-200 pt-4">
      <Button type="button" variant="outline" onClick={onCancel} disabled={pending}>
        <X className="mr-2 h-4 w-4" />
        Cancelar
      </Button>
      <Button type="submit" className="bg-stone-900 text-white hover:bg-stone-700" disabled={pending}>
        {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
        Salvar
      </Button>
    </div>
  );
}

function GaleriaTab() {
  const utils = trpc.useUtils();
  const listQuery = trpc.admin.galleryList.useQuery();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<GalleryForm>(emptyGalleryForm);
  const [showForm, setShowForm] = useState(false);

  const uploadImage = trpc.admin.uploadImage.useMutation({
    onSuccess: (result) => {
      setForm((current) => ({ ...current, imageUrl: result.url }));
      toast.success('Imagem enviada. Salve o item para publicar.');
    },
    onError: (error) => toast.error(error.message || 'Não foi possível enviar a imagem.'),
  });
  const createItem = trpc.admin.galleryCreate.useMutation({
    onSuccess: async () => {
      toast.success('Imagem adicionada à galeria.');
      await utils.admin.galleryList.invalidate();
      resetForm();
    },
    onError: (error) => toast.error(error.message || 'Não foi possível adicionar a imagem.'),
  });
  const updateItem = trpc.admin.galleryUpdate.useMutation({
    onSuccess: async () => {
      toast.success('Imagem atualizada.');
      await utils.admin.galleryList.invalidate();
      resetForm();
    },
    onError: (error) => toast.error(error.message || 'Não foi possível atualizar a imagem.'),
  });
  const deleteItem = trpc.admin.galleryDelete.useMutation({
    onSuccess: async () => {
      toast.success('Imagem removida.');
      await utils.admin.galleryList.invalidate();
    },
    onError: (error) => toast.error(error.message || 'Não foi possível remover a imagem.'),
  });

  function resetForm() {
    setForm(emptyGalleryForm);
    setEditingId(null);
    setShowForm(false);
  }

  function editItem(item: { id: number; title: string; description: string | null; imageUrl: string; category: string; displayOrder: number; isActive: number }) {
    setEditingId(item.id);
    setForm({
      title: item.title,
      description: item.description || '',
      imageUrl: item.imageUrl,
      category: item.category,
      displayOrder: String(item.displayOrder),
      isActive: item.isActive === 1,
    });
    setShowForm(true);
  }

  async function handleFileChange(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      toast.error('Escolha um arquivo de imagem.');
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      toast.error('A imagem deve ter no máximo 8 MB.');
      return;
    }
    const base64 = await readFileAsDataUrl(file);
    uploadImage.mutate({ fileName: file.name, fileBase64: base64, contentType: file.type });
  }

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!form.title.trim() || !form.imageUrl.trim()) {
      toast.error('Informe o título e uma imagem.');
      return;
    }
    const payload = {
      title: form.title.trim(),
      description: form.description.trim() || undefined,
      imageUrl: form.imageUrl.trim(),
      category: form.category,
      displayOrder: Number(form.displayOrder) || 0,
      isActive: form.isActive ? 1 : 0,
    };
    if (editingId) updateItem.mutate({ id: editingId, ...payload });
    else createItem.mutate(payload);
  }

  const pending = uploadImage.isPending || createItem.isPending || updateItem.isPending;

  return (
    <div className="space-y-6">
      <Card className="border-stone-200 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle>Galeria</CardTitle>
            <CardDescription>Gerencie as fotos que aparecem na galeria imersiva e na página inicial.</CardDescription>
          </div>
          {!showForm && (
            <Button onClick={() => setShowForm(true)} className="shrink-0 bg-amber-500 text-stone-950 hover:bg-amber-400">
              <Plus className="mr-2 h-4 w-4" /> Nova foto
            </Button>
          )}
        </CardHeader>
        {showForm && (
          <CardContent>
            <form onSubmit={handleSubmit} className="grid gap-4 rounded-xl bg-stone-50 p-4 md:grid-cols-2">
              <div>
                <FieldLabel>Título *</FieldLabel>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex.: Noite no Terraço" />
              </div>
              <div>
                <FieldLabel>Categoria *</FieldLabel>
                <select className="flex h-10 w-full rounded-md border border-stone-200 bg-white px-3 text-sm" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  {galleryCategories.map((category) => <option key={category.value} value={category.value}>{category.label}</option>)}
                </select>
              </div>
              <div className="md:col-span-2">
                <FieldLabel>Descrição</FieldLabel>
                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Uma breve descrição para acessibilidade e contexto." rows={3} />
              </div>
              <div className="md:col-span-2">
                <FieldLabel>Imagem *</FieldLabel>
                <div className="flex flex-col gap-3 sm:flex-row">
                  <Input value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} placeholder="URL da imagem ou envie um arquivo" />
                  <label className="inline-flex h-10 cursor-pointer items-center justify-center rounded-md border border-stone-300 bg-white px-4 text-sm font-medium hover:bg-stone-100">
                    {uploadImage.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                    Enviar arquivo
                    <input type="file" accept="image/*" className="sr-only" onChange={(e) => handleFileChange(e.target.files?.[0])} disabled={uploadImage.isPending} />
                  </label>
                </div>
                {form.imageUrl && <img src={form.imageUrl} alt="Pré-visualização" className="mt-3 h-36 w-full rounded-lg object-cover sm:w-64" />}
              </div>
              <div>
                <FieldLabel>Ordem de exibição</FieldLabel>
                <Input type="number" min="0" value={form.displayOrder} onChange={(e) => setForm({ ...form, displayOrder: e.target.value })} />
              </div>
              <label className="flex items-center gap-2 self-end pb-2 text-sm text-stone-700">
                <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} className="h-4 w-4 accent-amber-500" />
                Visível no site
              </label>
              <div className="md:col-span-2"><FormActions onCancel={resetForm} pending={pending} /></div>
            </form>
          </CardContent>
        )}
      </Card>

      {listQuery.isLoading ? <InlineLoader /> : listQuery.data?.length ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {listQuery.data.map((item) => (
            <Card key={item.id} className="overflow-hidden border-stone-200 shadow-sm">
              <div className="relative aspect-[16/10] bg-stone-100">
                <img src={item.imageUrl} alt={item.title} className="h-full w-full object-cover" />
                <span className={`absolute right-3 top-3 rounded-full px-2.5 py-1 text-xs font-semibold ${item.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-stone-200 text-stone-500'}`}>
                  {item.isActive ? 'Visível' : 'Oculta'}
                </span>
              </div>
              <CardContent className="p-4">
                <div className="mb-3 flex items-start justify-between gap-3">
                  <div><p className="font-semibold">{item.title}</p><p className="text-xs uppercase tracking-wide text-amber-700">{labelForCategory(item.category, galleryCategories)}</p></div>
                  <span className="text-xs text-stone-400">#{item.displayOrder}</span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => editItem(item)}><Pencil className="mr-2 h-3.5 w-3.5" /> Editar</Button>
                  <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700" onClick={() => { if (window.confirm('Remover esta imagem da galeria?')) deleteItem.mutate({ id: item.id }); }}><Trash2 className="mr-2 h-3.5 w-3.5" /> Remover</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : <EmptyState icon={<ImagePlus className="h-8 w-8" />} title="Sua galeria está vazia" description="Adicione a primeira foto real do Terraço Vieira para começar." onClick={() => setShowForm(true)} />}
    </div>
  );
}

function CardapioTab() {
  const utils = trpc.useUtils();
  const listQuery = trpc.admin.menuList.useQuery();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<MenuForm>(emptyMenuForm);
  const [showForm, setShowForm] = useState(false);

  const createItem = trpc.admin.menuCreate.useMutation({
    onSuccess: async () => { toast.success('Item adicionado ao cardápio.'); await utils.admin.menuList.invalidate(); resetForm(); },
    onError: (error) => toast.error(error.message || 'Não foi possível adicionar o item.'),
  });
  const updateItem = trpc.admin.menuUpdate.useMutation({
    onSuccess: async () => { toast.success('Item atualizado.'); await utils.admin.menuList.invalidate(); resetForm(); },
    onError: (error) => toast.error(error.message || 'Não foi possível atualizar o item.'),
  });
  const deleteItem = trpc.admin.menuDelete.useMutation({
    onSuccess: async () => { toast.success('Item removido.'); await utils.admin.menuList.invalidate(); },
    onError: (error) => toast.error(error.message || 'Não foi possível remover o item.'),
  });

  function resetForm() { setForm(emptyMenuForm); setEditingId(null); setShowForm(false); }
  function editItem(item: { id: number; name: string; description: string | null; price: string; category: string; displayOrder: number; isActive: number }) {
    setEditingId(item.id); setForm({ name: item.name, description: item.description || '', price: item.price, category: item.category, displayOrder: String(item.displayOrder), isActive: item.isActive === 1 }); setShowForm(true);
  }
  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!form.name.trim() || !form.price.trim()) { toast.error('Informe o nome e o preço do item.'); return; }
    const payload = { name: form.name.trim(), description: form.description.trim() || undefined, price: form.price.trim(), category: form.category, displayOrder: Number(form.displayOrder) || 0, isActive: form.isActive ? 1 : 0 };
    if (editingId) updateItem.mutate({ id: editingId, ...payload }); else createItem.mutate(payload);
  }
  const pending = createItem.isPending || updateItem.isPending;

  return (
    <div className="space-y-6">
      <Card className="border-stone-200 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div><CardTitle>Cardápio</CardTitle><CardDescription>Controle nomes, preços, categorias e disponibilidade dos itens.</CardDescription></div>
          {!showForm && <Button onClick={() => setShowForm(true)} className="shrink-0 bg-amber-500 text-stone-950 hover:bg-amber-400"><Plus className="mr-2 h-4 w-4" /> Novo item</Button>}
        </CardHeader>
        {showForm && <CardContent><form onSubmit={handleSubmit} className="grid gap-4 rounded-xl bg-stone-50 p-4 md:grid-cols-2">
          <div><FieldLabel>Nome *</FieldLabel><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex.: Copão Vieira" /></div>
          <div><FieldLabel>Preço *</FieldLabel><Input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="R$ 18,00" /></div>
          <div><FieldLabel>Categoria *</FieldLabel><select className="flex h-10 w-full rounded-md border border-stone-200 bg-white px-3 text-sm" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{menuCategories.map((category) => <option key={category.value} value={category.value}>{category.label}</option>)}</select></div>
          <div><FieldLabel>Ordem de exibição</FieldLabel><Input type="number" min="0" value={form.displayOrder} onChange={(e) => setForm({ ...form, displayOrder: e.target.value })} /></div>
          <div className="md:col-span-2"><FieldLabel>Descrição</FieldLabel><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Ingredientes ou detalhes do item." rows={3} /></div>
          <label className="flex items-center gap-2 text-sm text-stone-700"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} className="h-4 w-4 accent-amber-500" /> Disponível no site</label>
          <div className="md:col-span-2"><FormActions onCancel={resetForm} pending={pending} /></div>
        </form></CardContent>}
      </Card>

      {listQuery.isLoading ? <InlineLoader /> : listQuery.data?.length ? (
        <div className="overflow-x-auto rounded-xl border border-stone-200 bg-white shadow-sm">
          <table className="w-full min-w-[720px] text-left text-sm"><thead className="border-b border-stone-200 bg-stone-50 text-xs uppercase tracking-wide text-stone-500"><tr><th className="px-4 py-3">Item</th><th className="px-4 py-3">Categoria</th><th className="px-4 py-3">Preço</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Ações</th></tr></thead><tbody className="divide-y divide-stone-100">{listQuery.data.map((item) => <tr key={item.id} className="hover:bg-stone-50"><td className="px-4 py-4"><p className="font-semibold">{item.name}</p><p className="max-w-sm truncate text-xs text-stone-500">{item.description || 'Sem descrição'}</p></td><td className="px-4 py-4 text-stone-600">{labelForCategory(item.category, menuCategories)}</td><td className="px-4 py-4 font-semibold text-amber-700">{item.price}</td><td className="px-4 py-4"><span className={`rounded-full px-2.5 py-1 text-xs font-medium ${item.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-stone-200 text-stone-500'}`}>{item.isActive ? 'Disponível' : 'Oculto'}</span></td><td className="px-4 py-4"><div className="flex justify-end gap-2"><Button variant="outline" size="sm" onClick={() => editItem(item)}><Pencil className="mr-2 h-3.5 w-3.5" /> Editar</Button><Button variant="outline" size="sm" className="text-red-600 hover:text-red-700" onClick={() => { if (window.confirm('Remover este item do cardápio?')) deleteItem.mutate({ id: item.id }); }}><Trash2 className="mr-2 h-3.5 w-3.5" /> Remover</Button></div></td></tr>)}</tbody></table>
        </div>
      ) : <EmptyState title="Seu cardápio está vazio" description="Cadastre os itens e preços praticados no Terraço Vieira." onClick={() => setShowForm(true)} />}
    </div>
  );
}

function ConfiguracoesTab() {
  const settingsQuery = trpc.admin.allSettings.useQuery();
  const setSetting = trpc.admin.setSetting.useMutation();
  const [form, setForm] = useState(defaultSettings);

  useEffect(() => {
    if (settingsQuery.data) setForm({ ...defaultSettings, ...settingsQuery.data });
  }, [settingsQuery.data]);

  async function handleSave(event: React.FormEvent) {
    event.preventDefault();
    try {
      await Promise.all(Object.entries(form).map(([key, value]) => setSetting.mutateAsync({ key, value })));
      toast.success('Configurações salvas.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não foi possível salvar as configurações.');
    }
  }

  if (settingsQuery.isLoading) return <InlineLoader />;

  return <Card className="border-stone-200 shadow-sm"><CardHeader><CardTitle>Configurações do site</CardTitle><CardDescription>Essas informações são compartilhadas pelas áreas públicas do site.</CardDescription></CardHeader><CardContent><form onSubmit={handleSave} className="grid gap-5 md:grid-cols-2">
    <div><FieldLabel>Nome do estabelecimento</FieldLabel><Input value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} /></div>
    <div><FieldLabel>Endereço</FieldLabel><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
    <div><FieldLabel>WhatsApp (somente números)</FieldLabel><Input value={form.whatsapp_number} onChange={(e) => setForm({ ...form, whatsapp_number: e.target.value })} placeholder="5586999999999" /></div>
    <div><FieldLabel>Instagram</FieldLabel><Input value={form.instagram_url} onChange={(e) => setForm({ ...form, instagram_url: e.target.value })} placeholder="https://instagram.com/..." /></div>
    <div><FieldLabel>Horário durante a semana</FieldLabel><Input value={form.hours_weekdays} onChange={(e) => setForm({ ...form, hours_weekdays: e.target.value })} /></div>
    <div><FieldLabel>Horário de fim de semana</FieldLabel><Input value={form.hours_weekend} onChange={(e) => setForm({ ...form, hours_weekend: e.target.value })} /></div>
    <div className="flex justify-end md:col-span-2"><Button type="submit" className="bg-stone-900 text-white hover:bg-stone-700" disabled={setSetting.isPending}>{setSetting.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Salvar configurações</Button></div>
  </form></CardContent></Card>;
}

function InlineLoader() {
  return <div className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-stone-300 bg-white py-16 text-sm text-stone-500"><Loader2 className="h-4 w-4 animate-spin text-amber-600" /> Carregando dados…</div>;
}

function EmptyState({ icon, title, description, onClick }: { icon?: React.ReactNode; title: string; description: string; onClick: () => void }) {
  return <Card className="border-dashed border-stone-300 bg-white shadow-none"><CardContent className="flex flex-col items-center justify-center py-16 text-center">{icon && <div className="mb-3 text-stone-300">{icon}</div>}<h3 className="font-semibold text-stone-800">{title}</h3><p className="mt-1 max-w-md text-sm text-stone-500">{description}</p><Button className="mt-5 bg-amber-500 text-stone-950 hover:bg-amber-400" onClick={onClick}><Plus className="mr-2 h-4 w-4" /> Adicionar agora</Button></CardContent></Card>;
}

function labelForCategory(value: string, categories: { value: string; label: string }[]) {
  return categories.find((category) => category.value === value)?.label || value;
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Falha ao ler o arquivo.'));
    reader.readAsDataURL(file);
  });
}
const _unused = [ImagePlus];
void _unused;

