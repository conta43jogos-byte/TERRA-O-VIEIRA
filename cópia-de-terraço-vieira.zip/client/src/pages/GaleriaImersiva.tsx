/**
 * Terraço Vieira — Galeria Imersiva com Filtros
 * Categorias: Ambiente, Gastronomia, Eventos Privados, Drinks
 */
import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Loader2, X } from 'lucide-react';

const categoryLabels: Record<string, string> = {
  'ambiente': '🏠 Ambiente',
  'gastronomia': '🍽️ Gastronomia',
  'eventos': '🎉 Eventos',
  'drinks': '🍹 Drinks',
};

export default function GaleriaImersiva() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const { data: categories = [], isLoading: categoriesLoading } = trpc.gallery.categories.useQuery();
  const { data: items = [], isLoading: itemsLoading } = trpc.gallery.items.useQuery(
    selectedCategory ? { category: selectedCategory } : undefined
  );

  const displayItems = items;

  return (
    <div style={{ minHeight: '100vh', background: '#faf6f0', padding: '2rem 0' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: '3rem', paddingTop: '2rem' }}>
        <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: '0.75rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#e8820c', marginBottom: '0.75rem' }}>
          GALERIA IMERSIVA
        </p>
        <h1 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontWeight: 700, fontSize: 'clamp(2rem, 4vw, 3rem)', color: '#0d0d0d', marginBottom: '1rem' }}>
          Explore o Terraço Vieira
        </h1>
        <p style={{ fontFamily: "'Nunito', sans-serif", fontSize: '1rem', color: '#666', maxWidth: '500px', margin: '0 auto' }}>
          Descubra cada momento especial do nosso espaço através de nossas categorias de fotos e vídeos.
        </p>
      </div>

      <div className="container" style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1rem' }}>
        {/* Category Filters */}
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', justifyContent: 'center', marginBottom: '3rem' }}>
          <button
            onClick={() => setSelectedCategory(null)}
            style={{
              fontFamily: "'Nunito', sans-serif",
              fontWeight: 700,
              fontSize: '0.875rem',
              padding: '0.6rem 1.25rem',
              borderRadius: '100px',
              border: '2px solid',
              borderColor: selectedCategory === null ? '#e8820c' : '#e0d8cc',
              background: selectedCategory === null ? '#e8820c' : 'transparent',
              color: selectedCategory === null ? '#0d0d0d' : '#555',
              transition: 'all 150ms ease',
              cursor: 'pointer',
            }}
          >
            Todas
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 700,
                fontSize: '0.875rem',
                padding: '0.6rem 1.25rem',
                borderRadius: '100px',
                border: '2px solid',
                borderColor: selectedCategory === cat ? '#e8820c' : '#e0d8cc',
                background: selectedCategory === cat ? '#e8820c' : 'transparent',
                color: selectedCategory === cat ? '#0d0d0d' : '#555',
                transition: 'all 150ms ease',
                cursor: 'pointer',
              }}
            >
              {categoryLabels[cat] || cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        {itemsLoading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>
            <Loader2 className="animate-spin" size={32} />
          </div>
        ) : displayItems.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '4rem 1rem', color: '#777' }}>
            <p style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: '1.35rem', color: '#3a2514', marginBottom: '0.5rem' }}>Ainda estamos preparando esta galeria.</p>
            <p style={{ fontFamily: "'Nunito', sans-serif", fontSize: '0.95rem' }}>Novas fotos do Terraço Vieira aparecerão aqui em breve.</p>
          </div>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: '1rem',
          }}>
            {displayItems.map((item) => (
              <div
                key={item.id}
                role="button"
                tabIndex={0}
                aria-label={`Ampliar foto: ${item.title}`}
                onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') setSelectedImage(item.imageUrl); }}
                onClick={() => setSelectedImage(item.imageUrl)}
                style={{
                  position: 'relative',
                  borderRadius: '12px',
                  overflow: 'hidden',
                  aspectRatio: '1',
                  cursor: 'pointer',
                  transition: 'transform 300ms ease',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.transform = 'scale(1.05)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.transform = 'scale(1)';
                }}
              >
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    display: 'block',
                  }}
                />
                <div style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'linear-gradient(to top, rgba(13,13,13,0.8) 0%, transparent 60%)',
                  display: 'flex',
                  alignItems: 'flex-end',
                  padding: '1rem',
                }}>
                  <div>
                    <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: '0.9rem', color: '#f5f0e8' }}>
                      {item.title}
                    </p>
                    {item.description && (
                      <p style={{ fontFamily: "'Nunito', sans-serif", fontSize: '0.8rem', color: 'rgba(245,240,232,0.7)', marginTop: '0.25rem' }}>
                        {item.description}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.95)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
            padding: '1rem',
          }}
          onClick={() => setSelectedImage(null)}
        >
          <button
            aria-label="Fechar imagem ampliada"
            onClick={() => setSelectedImage(null)}
            style={{
              position: 'absolute',
              top: '1rem',
              right: '1rem',
              background: 'rgba(255,255,255,0.1)',
              border: 'none',
              color: '#fff',
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'background 150ms ease',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.2)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.1)';
            }}
          >
            <X size={20} />
          </button>
          <img
            src={selectedImage}
            alt="Full size"
            style={{
              maxWidth: '90vw',
              maxHeight: '90vh',
              objectFit: 'contain',
              borderRadius: '8px',
            }}
          />
        </div>
      )}
    </div>
  );
}

