/**
 * Terraço Vieira — Home Page
 * Design: Nordestino Premium
 * Sections: Navbar, Hero, Sobre, Cardápio, Mansão Maromba, Galeria, Contato, Footer
 */
import { useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import SobreSection from '@/components/SobreSection';
import CardapioSection from '@/components/CardapioSection';
import MansaoSection from '@/components/MansaoSection';
import GaleriaSection from '@/components/GaleriaSection';
import ContatoSection from '@/components/ContatoSection';
import Footer from '@/components/Footer';
import WhatsAppFloat from '@/components/WhatsAppFloat';

export default function Home() {
  const settingsQuery = trpc.settings.all.useQuery();
  const businessName = settingsQuery.data?.business_name || 'Terraço Vieira';

  useEffect(() => {
    document.title = `${businessName} | Bar e restaurante em Inhuma`;
  }, [businessName]);

  return (
    <div style={{ minHeight: '100vh', background: '#faf6f0' }}>
      <Navbar />
      <main aria-label={`Conteúdo principal do ${businessName}`}>
        <HeroSection />
        <SobreSection />
        <CardapioSection />
        <MansaoSection />
        <GaleriaSection />
        <ContatoSection />
      </main>
      <Footer />
      <WhatsAppFloat />
    </div>
  );
}
