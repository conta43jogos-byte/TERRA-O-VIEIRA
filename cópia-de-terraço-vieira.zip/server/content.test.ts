import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(user: TrpcContext["user"]): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const regularUser = {
  id: 2,
  openId: "regular-user",
  email: "user@example.com",
  name: "Visitante",
  loginMethod: "manus",
  role: "user" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

const adminUser = {
  ...regularUser,
  id: 1,
  openId: "admin-user",
  email: "admin@example.com",
  name: "Administrador",
  role: "admin" as const,
};

describe("content access control", () => {
  it("blocks regular users from gallery mutations", async () => {
    const caller = appRouter.createCaller(createContext(regularUser));

    await expect(caller.admin.galleryCreate({
      title: "Foto não autorizada",
      imageUrl: "https://example.com/image.jpg",
      category: "ambiente",
      displayOrder: 0,
      isActive: 1,
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("blocks regular users from image uploads", async () => {
    const caller = appRouter.createCaller(createContext(regularUser));

    await expect(caller.admin.uploadImage({
      fileName: "foto.jpg",
      fileBase64: "data:image/jpeg;base64,ZmFrZQ==",
      contentType: "image/jpeg",
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("exposes public content routes without authentication", async () => {
    const caller = appRouter.createCaller(createContext(null));
    const [menu, settings] = await Promise.all([
      caller.menu.items(),
      caller.settings.all(),
    ]);

    expect(Array.isArray(menu)).toBe(true);
    expect(settings).toBeTypeOf("object");
  });

  it("allows the admin context to reach protected queries", async () => {
    const caller = appRouter.createCaller(createContext(adminUser));
    const settings = await caller.admin.allSettings();

    expect(settings).toBeTypeOf("object");
  });
});
