import { eq, asc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, galleryItems, GalleryItem, InsertGalleryItem, menuItems, MenuItem, InsertMenuItem, siteSettings, SiteSetting } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Gallery queries & mutations
export async function getGalleryItems(category?: string): Promise<GalleryItem[]> {
  const db = await getDb();
  if (!db) return [];

  if (category) {
    return await db.select().from(galleryItems)
      .where(and(eq(galleryItems.isActive, 1), eq(galleryItems.category, category)))
      .orderBy(asc(galleryItems.displayOrder));
  }
  
  return await db.select().from(galleryItems)
    .where(eq(galleryItems.isActive, 1))
    .orderBy(asc(galleryItems.displayOrder));
}

export async function getAllGalleryItemsAdmin(): Promise<GalleryItem[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(galleryItems).orderBy(asc(galleryItems.displayOrder));
}

export async function createGalleryItem(item: InsertGalleryItem): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(galleryItems).values(item);
  return Number(result[0].insertId);
}

export async function updateGalleryItem(id: number, item: Partial<InsertGalleryItem>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(galleryItems).set(item).where(eq(galleryItems.id, id));
}

export async function deleteGalleryItem(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(galleryItems).where(eq(galleryItems.id, id));
}

export async function getGalleryCategories(): Promise<string[]> {
  const db = await getDb();
  if (!db) return [];

  const items = await db.select({ category: galleryItems.category }).from(galleryItems).where(eq(galleryItems.isActive, 1));
  const categories = new Set(items.map(i => i.category));
  return Array.from(categories);
}

// Menu queries & mutations
export async function getMenuItems(category?: string): Promise<MenuItem[]> {
  const db = await getDb();
  if (!db) return [];

  if (category) {
    return await db.select().from(menuItems)
      .where(and(eq(menuItems.isActive, 1), eq(menuItems.category, category)))
      .orderBy(asc(menuItems.displayOrder));
  }
  
  return await db.select().from(menuItems)
    .where(eq(menuItems.isActive, 1))
    .orderBy(asc(menuItems.displayOrder));
}

export async function getAllMenuItemsAdmin(): Promise<MenuItem[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(menuItems).orderBy(asc(menuItems.displayOrder));
}

export async function createMenuItem(item: InsertMenuItem): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(menuItems).values(item);
  return Number(result[0].insertId);
}

export async function updateMenuItem(id: number, item: Partial<InsertMenuItem>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(menuItems).set(item).where(eq(menuItems.id, id));
}

export async function deleteMenuItem(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(menuItems).where(eq(menuItems.id, id));
}

// Site settings
export async function getSiteSetting(key: string): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(siteSettings).where(eq(siteSettings.key, key)).limit(1);
  return result.length > 0 ? result[0].value : null;
}

export async function setSiteSetting(key: string, value: string): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(siteSettings).values({ key, value }).onDuplicateKeyUpdate({
    set: { value },
  });
}

export async function getAllSiteSettings(): Promise<Record<string, string>> {
  const db = await getDb();
  if (!db) return {};

  const rows = await db.select().from(siteSettings);
  const settings: Record<string, string> = {};
  for (const row of rows) {
    settings[row.key] = row.value;
  }
  return settings;
}
