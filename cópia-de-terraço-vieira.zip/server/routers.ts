import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { 
  getGalleryItems, 
  getAllGalleryItemsAdmin,
  createGalleryItem,
  updateGalleryItem,
  deleteGalleryItem,
  getGalleryCategories, 
  getMenuItems, 
  getAllMenuItemsAdmin,
  createMenuItem,
  updateMenuItem,
  deleteMenuItem,
  setSiteSetting, 
  getSiteSetting,
  getAllSiteSettings
} from "./db";
import { storagePut } from "./storage";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  gallery: router({
    items: publicProcedure
      .input(z.object({ category: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await getGalleryItems(input?.category);
      }),
    categories: publicProcedure.query(async () => {
      return await getGalleryCategories();
    }),
  }),

  menu: router({
    items: publicProcedure
      .input(z.object({ category: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await getMenuItems(input?.category);
      }),
  }),

  settings: router({
    all: publicProcedure.query(async () => {
      return await getAllSiteSettings();
    }),
  }),

  admin: router({
    // Settings
    getSetting: protectedProcedure
      .input(z.object({ key: z.string() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        return await getSiteSetting(input.key);
      }),
    setSetting: protectedProcedure
      .input(z.object({ key: z.string(), value: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await setSiteSetting(input.key, input.value);
        return { success: true };
      }),
    allSettings: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return await getAllSiteSettings();
    }),

    // Gallery Admin
    galleryList: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return await getAllGalleryItemsAdmin();
    }),
    galleryCreate: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        imageUrl: z.string(),
        category: z.string(),
        displayOrder: z.number().default(0),
        isActive: z.number().default(1),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        const id = await createGalleryItem(input);
        return { success: true, id };
      }),
    galleryUpdate: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        imageUrl: z.string().optional(),
        category: z.string().optional(),
        displayOrder: z.number().optional(),
        isActive: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        const { id, ...data } = input;
        await updateGalleryItem(id, data);
        return { success: true };
      }),
    galleryDelete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await deleteGalleryItem(input.id);
        return { success: true };
      }),

    // Menu Admin
    menuList: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return await getAllMenuItemsAdmin();
    }),
    menuCreate: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        price: z.string(),
        category: z.string(),
        displayOrder: z.number().default(0),
        isActive: z.number().default(1),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        const id = await createMenuItem(input);
        return { success: true, id };
      }),
    menuUpdate: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        price: z.string().optional(),
        category: z.string().optional(),
        displayOrder: z.number().optional(),
        isActive: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        const { id, ...data } = input;
        await updateMenuItem(id, data);
        return { success: true };
      }),
    menuDelete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await deleteMenuItem(input.id);
        return { success: true };
      }),

    // S3 Image Upload
    uploadImage: protectedProcedure
      .input(z.object({
        fileName: z.string(),
        fileBase64: z.string(), // base64 encoded file
        contentType: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        
        // Strip data url prefix if present (e.g. data:image/jpeg;base64,)
        const base64Data = input.fileBase64.replace(/^data:.*;base64,/, "");
        const buffer = Buffer.from(base64Data, 'base64');
        
        const result = await storagePut(input.fileName, buffer, input.contentType);
        return result;
      }),
  }),
});

export type AppRouter = typeof appRouter;
