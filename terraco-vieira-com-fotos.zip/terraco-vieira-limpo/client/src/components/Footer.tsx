/**
 * Terraço Vieira — Footer
 * Design: Nordestino Premium — very dark bg, brand mark prominent, amber accent
 */
import { Instagram, MessageCircle, MapPin } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer style={{
      background: '#080808',
      borderTop: '1px solid rgba(232,130,12,0.15)',
      padding: '3rem 0 2rem',
    }}>
      <div className="container">
        {/* Top row */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'auto 1fr auto',
          gap: '2rem',
          alignItems: 'start',
          marginBottom: '2.5rem',
          flexWrap: 'wrap',
        }}>
          {/* Brand */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '0.75rem' }}>
              <div style={{
                width: '44px',
                height: '44px',
                borderRadius: '50%',
                border: '2px solid rgba(232,130,12,0.5)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'rgba(232,130,12,0.08)',
              }}>
                <img src="/storage/terraco-logo_f16cb1b2.png" alt="" style={{ width: '34px', height: '34px', objectFit: 'contain' }} />
              </div>
              <div>
                <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 900, fontSize: '1rem', color: '#f5f0e8', lineHeight: 1, letterSpacing: '0.06em' }}>TERRAÇO</p>
                <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 900, fontSize: '1rem', color: '#e8820c', lineHeight: 1, letterSpacing: '0.06em' }}>VIEIRA & VIEIRA</p>
              </div>
            </div>
            <p style={{ fontFamily: "'Nunito', sans-serif", fontSize: '0.8rem', color: '#444', lineHeight: 1.5 }}>
              Bar & Distribuidora<br />Inhuma — Piauí
            </p>
          </div>

          {/* Address */}
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem' }}>
            <MapPin size={14} style={{ color: '#e8820c', marginTop: '2px', flexShrink: 0 }} />
            <p style={{ fontFamily: "'Nunito', sans-serif", fontSize: '0.8rem', color: '#444', lineHeight: 1.6 }}>
              Av. Castelo Branco, 1290<br />
              Inhuma - PI, 64535-000<br />
              Próximo ao Posto São Cristóvão
            </p>
          </div>

          {/* Social */}
          <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
            <a href="https://instagram.com/terraco_vieira" target="_blank" rel="noopener noreferrer"
              style={{
                width: '40px', height: '40px', borderRadius: '50%',
                border: '1px solid rgba(255,255,255,0.1)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#555', transition: 'all 150ms ease',
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = '#e8820c'; (e.currentTarget as HTMLElement).style.color = '#e8820c'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(255,255,255,0.1)'; (e.currentTarget as HTMLElement).style.color = '#555'; }}
              aria-label="Instagram"
            >
              <Instagram size={18} />
            </a>
            <a href="https://wa.me/558681484273" target="_blank" rel="noopener noreferrer"
              style={{
                width: '40px', height: '40px', borderRadius: '50%',
                border: '1px solid rgba(255,255,255,0.1)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#555', transition: 'all 150ms ease',
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = '#e8820c'; (e.currentTarget as HTMLElement).style.color = '#e8820c'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(255,255,255,0.1)'; (e.currentTarget as HTMLElement).style.color = '#555'; }}
              aria-label="WhatsApp"
            >
              <MessageCircle size={18} />
            </a>
          </div>
        </div>

        {/* Divider */}
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '1.5rem' }}>
          <p style={{
            fontFamily: "'Nunito', sans-serif",
            fontSize: '0.75rem',
            color: '#333',
            textAlign: 'center',
          }}>
            © {year} Terraço Vieira & Vieira Distribuidora. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}

