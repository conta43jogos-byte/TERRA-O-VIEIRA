/**
 * Terraço Vieira — Galeria Section
 * Design: Nordestino Premium — dark bg, dramatic grid, hover reveal with amber overlay
 */
import { trpc } from '@/lib/trpc';

const galleryImages = [
  { src: '/fotos/foto-1.jpeg', alt: 'Terraço Vieira', label: 'O Terraço', wide: true },
  { src: '/fotos/foto-2.jpeg', alt: 'Terraço Vieira', label: 'Nossa Galera', wide: false },
  { src: '/fotos/foto-3.jpeg', alt: 'Terraço Vieira', label: 'Bons Momentos', wide: false },
  { src: '/fotos/foto-4.jpeg', alt: 'Terraço Vieira', label: 'Nosso Espaço', wide: false },
  { src: '/fotos/foto-5.jpeg', alt: 'Terraço Vieira', label: 'Momentos Especiais', wide: false },
  { src: '/fotos/foto-6.jpeg', alt: 'Terraço Vieira', label: 'Terraço Vieira', wide: false },
];

export default function GaleriaSection() {
  const galleryQuery = trpc.gallery.items.useQuery();
  const images = galleryQuery.data?.length
    ? galleryQuery.data.map((item, index) => ({
        src: item.imageUrl,
        alt: item.title,
        label: item.title,
        wide: index === 0,
      }))
    : galleryImages;

  return (
    <section id="galeria" style={{ background: '#f5ede0', padding: '6rem 0' }}>
      <div className="container">
        {/* Header — left aligned */}
        <div style={{ marginBottom: '3rem' }}>
          <p className="section-label" style={{ marginBottom: '0.75rem' }}>Galeria</p>
          <h2 style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontWeight: 700,
            fontSize: 'clamp(2rem, 4vw, 3rem)',
            color: '#1a0f00',
            lineHeight: 1.2,
            marginBottom: '0.5rem',
          }}>
            O clima do Terraço
          </h2>
          <p style={{
            fontFamily: "'Nunito', sans-serif",
            fontSize: '1rem',
            color: '#6b4c2a',
            maxWidth: '440px',
            lineHeight: 1.6,
          }}>
            Um espaço feito para bons momentos. Veja como é o nosso terraço.
          </p>
        </div>

        {/* Gallery grid — masonry-like */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gridAutoRows: '220px',
          gap: '0.75rem',
        }}>
          {images.map((img, i) => (
            <div key={i} style={{
              position: 'relative',
              borderRadius: '10px',
              overflow: 'hidden',
              gridColumn: img.wide ? 'span 2' : 'span 1',
              cursor: 'pointer',
            }}
              onMouseEnter={(e) => {
                const overlay = (e.currentTarget as HTMLElement).querySelector('.gallery-overlay') as HTMLElement;
                const imgEl = (e.currentTarget as HTMLElement).querySelector('img') as HTMLElement;
                if (overlay) overlay.style.opacity = '1';
                if (imgEl) imgEl.style.transform = 'scale(1.06)';
              }}
              onMouseLeave={(e) => {
                const overlay = (e.currentTarget as HTMLElement).querySelector('.gallery-overlay') as HTMLElement;
                const imgEl = (e.currentTarget as HTMLElement).querySelector('img') as HTMLElement;
                if (overlay) overlay.style.opacity = '0';
                if (imgEl) imgEl.style.transform = 'scale(1)';
              }}
            >
              <img src={img.src} alt={img.alt} style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                display: 'block',
                transition: 'transform 500ms cubic-bezier(0.23,1,0.32,1)',
              }} />
              <div className="gallery-overlay" style={{
                position: 'absolute',
                inset: 0,
                background: 'linear-gradient(to top, rgba(26,15,0,0.9) 0%, rgba(232,130,12,0.15) 100%)',
                opacity: 0,
                transition: 'opacity 300ms ease',
                display: 'flex',
                alignItems: 'flex-end',
                padding: '1rem 1.25rem',
              }}>
                <span style={{
                  fontFamily: "'Nunito', sans-serif",
                  fontWeight: 700,
                  fontSize: '0.9rem',
                  color: '#f5f0e8',
                  letterSpacing: '0.05em',
                }}>{img.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

