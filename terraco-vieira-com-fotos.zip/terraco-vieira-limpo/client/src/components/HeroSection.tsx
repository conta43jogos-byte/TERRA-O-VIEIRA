/**
 * Terraço Vieira — Hero Section
 * Design: Nordestino Premium — dark overlay, left-aligned text, amber CTAs
 * Background: real photo of the space with gradient overlay
 */
import { ChevronDown, MessageCircle, UtensilsCrossed } from 'lucide-react';

export default function HeroSection() {
  const scrollToSection = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="inicio" style={{
      position: 'relative',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      overflow: 'hidden',
      background: '#0d0d0d',
    }}>
      {/* Background image */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `url('/fotos/foto-1.jpeg')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }} />

      {/* Dark overlay */}
      <div style={{
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(105deg, rgba(13,13,13,0.88) 0%, rgba(13,13,13,0.65) 55%, rgba(13,13,13,0.3) 100%)',
      }} />

      {/* Content */}
      <div className="container" style={{ position: 'relative', zIndex: 2, paddingTop: '100px', paddingBottom: '80px' }}>
        <div style={{ maxWidth: '680px' }}>
          {/* Status badge */}
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            background: 'rgba(232,130,12,0.15)',
            border: '1px solid rgba(232,130,12,0.4)',
            borderRadius: '100px',
            padding: '6px 14px',
            marginBottom: '1.5rem',
          }}>
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#e8820c', display: 'inline-block', animation: 'pulse 2s infinite' }} />
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: '0.8rem', color: '#e8820c', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Abre seg-sex 16h às 23h
            </span>
          </div>

          {/* Headline */}
          <h1 style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontWeight: 900,
            fontSize: 'clamp(2.8rem, 7vw, 5.5rem)',
            lineHeight: 1.05,
            color: '#f5f0e8',
            marginBottom: '1.5rem',
            letterSpacing: '-0.02em',
          }}>
            Seu ponto de<br />
            encontro em{' '}
            <span style={{ color: '#e8820c' }}>Inhuma</span>
          </h1>

          {/* Subheadline */}
          <p style={{
            fontFamily: "'Nunito', sans-serif",
            fontWeight: 400,
            fontSize: 'clamp(1rem, 2vw, 1.2rem)',
            color: 'rgba(245,240,232,0.8)',
            lineHeight: 1.7,
            marginBottom: '2.5rem',
            maxWidth: '520px',
          }}>
            O lugar perfeito para relaxar, curtir uma boa música, assistir ao jogo do seu time e saborear aquela cerveja trincando com os amigos.
          </p>

          {/* CTAs */}
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            <button className="btn-amber" onClick={() => scrollToSection('#cardapio')}>
              <UtensilsCrossed size={18} />
              Ver Cardápio
            </button>
            <a href="https://wa.me/558681484273?text=Olá!%20Vim%20pelo%20site%20do%20Terraço%20Vieira%20e%20gostaria%20de%20fazer%20uma%20reserva."
              target="_blank" rel="noopener noreferrer"
              className="btn-outline-amber"
              style={{ color: '#f5f0e8', borderColor: 'rgba(245,240,232,0.5)' }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'rgba(245,240,232,0.1)'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
            >
              <MessageCircle size={18} />
              Reservar Mesa
            </a>
          </div>

          {/* Feature tags */}
          <div style={{ display: 'flex', gap: '1.5rem', marginTop: '3rem', flexWrap: 'wrap' }}>
            {['🍺 Cervejas Geladas', '🍖 Petiscos na Hora', '📺 Transmissão de Jogos'].map((tag) => (
              <span key={tag} style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 600,
                fontSize: '0.8rem',
                color: 'rgba(245,240,232,0.6)',
                letterSpacing: '0.05em',
              }}>{tag}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={() => scrollToSection('#sobre')}
        aria-label="Rolar para baixo"
        style={{
          position: 'absolute',
          bottom: '2rem',
          left: '50%',
          transform: 'translateX(-50%)',
          background: 'none',
          border: 'none',
          color: 'rgba(245,240,232,0.5)',
          cursor: 'pointer',
          animation: 'bounce 2s infinite',
          zIndex: 2,
        }}
      >
        <ChevronDown size={28} />
      </button>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes bounce {
          0%, 100% { transform: translateX(-50%) translateY(0); }
          50% { transform: translateX(-50%) translateY(8px); }
        }
      `}</style>
    </section>
  );
}
