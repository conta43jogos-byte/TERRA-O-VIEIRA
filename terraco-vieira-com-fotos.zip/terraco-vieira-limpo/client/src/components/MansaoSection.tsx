/**
 * Terraço Vieira — Mansão Maromba Section
 * Design: Nordestino Premium — dark background, amber neon text, exclusive line highlight
 */
import { MessageCircle, Zap } from 'lucide-react';

export default function MansaoSection() {
  return (
    <section style={{
      background: '#0d0d0d',
      padding: '6rem 0',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Background texture */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `url('/storage/terraco-cerveja_e7ff7b4a.jpg')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        opacity: 0.12,
      }} />
      <div style={{
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(135deg, rgba(13,13,13,0.95) 0%, rgba(13,13,13,0.8) 100%)',
      }} />

      <div className="container" style={{ position: 'relative', zIndex: 1 }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            background: 'rgba(232,130,12,0.15)',
            border: '1px solid rgba(232,130,12,0.3)',
            borderRadius: '100px',
            padding: '6px 16px',
            marginBottom: '1.5rem',
          }}>
            <Zap size={14} style={{ color: '#e8820c' }} />
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: '0.75rem', color: '#e8820c', letterSpacing: '0.15em', textTransform: 'uppercase' }}>
              Linha Exclusiva
            </span>
          </div>
          <h2 style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontWeight: 900,
            fontSize: 'clamp(2.5rem, 6vw, 4.5rem)',
            color: '#e8820c',
            letterSpacing: '-0.02em',
            lineHeight: 1,
            marginBottom: '1rem',
            textShadow: '0 0 60px rgba(232,130,12,0.3)',
          }}>
            MANSÃO MAROMBA
          </h2>
          <p style={{
            fontFamily: "'Nunito', sans-serif",
            fontSize: '1.1rem',
            color: 'rgba(245,240,232,0.7)',
            maxWidth: '480px',
            margin: '0 auto',
            lineHeight: 1.7,
          }}>
            A energia certa para a sua noite com as bebidas oficiais da linha.
          </p>
        </div>

        {/* Product card */}
        <div style={{ maxWidth: '520px', margin: '0 auto' }}>
          <div style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(232,130,12,0.3)',
            borderRadius: '16px',
            padding: '2rem',
            display: 'flex',
            gap: '1.5rem',
            alignItems: 'center',
            backdropFilter: 'blur(8px)',
          }}>
            <img
              src="https://media.base44.com/images/public/6a599cb40342b0292f61fb4f/b94889173_IMG_20260717_002320.jpg"
              alt="Bebidas e Drinks Mansão Maromba"
              style={{
                width: '100px',
                height: '100px',
                objectFit: 'cover',
                borderRadius: '12px',
                flexShrink: 0,
              }}
            />
            <div style={{ flex: 1 }}>
              <h3 style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 800,
                fontSize: '1.1rem',
                color: '#f5f0e8',
                marginBottom: '0.4rem',
              }}>Bebidas e Drinks Mansão Maromba</h3>
              <p style={{
                fontFamily: "'Nunito', sans-serif",
                fontSize: '0.85rem',
                color: 'rgba(245,240,232,0.6)',
                marginBottom: '1rem',
                lineHeight: 1.5,
              }}>A energia certa para a sua noite com as bebidas oficiais da linha.</p>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{
                  fontFamily: "'Nunito', sans-serif",
                  fontWeight: 800,
                  fontSize: '1.25rem',
                  color: '#e8820c',
                }}>R$ 20,00</span>
                <a href="https://wa.me/558681484273?text=Olá!%20Quero%20pedir%3A%20Bebidas%20e%20Drinks%20Mansão%20Maromba"
                  target="_blank" rel="noopener noreferrer"
                  className="btn-amber"
                  style={{ padding: '0.55rem 1.25rem', fontSize: '0.875rem' }}
                >
                  <MessageCircle size={15} />
                  Pedir Agora
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
