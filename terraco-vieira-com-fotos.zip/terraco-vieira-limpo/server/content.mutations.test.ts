import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getGalleryItems: vi.fn().mockResolvedValue([]),
  getAllGalleryItemsAdmin: vi.fn().mockResolvedValue([]),
  createGalleryItem: vi.fn().mockResolvedValue(101),
  updateGalleryItem: vi.fn().mockResolvedValue(undefined),
  deleteGalleryItem: vi.fn().mockResolvedValue(undefined),
  getGalleryCategories: vi.fn().mockResolvedValue([]),
  getMenuItems: vi.fn().mockResolvedValue([]),
  getAllMenuItemsAdmin: vi.fn().mockResolvedValue([]),
  createMenuItem: vi.fn().mockResolvedValue(202),
  updateMenuItem: vi.fn().mockResolvedValue(undefined),
  deleteMenuItem: vi.fn().mockResolvedValue(undefined),
  setSiteSetting: vi.fn().mockResolvedValue(undefined),
  getSiteSetting: vi.fn().mockResolvedValue(null),
  getAllSiteSettings: vi.fn().mockResolvedValue({}),
  storagePut: vi.fn().mockResolvedValue({ key: "gallery/foto_abc.jpg", url: "/storage/gallery/foto_abc.jpg" }),
}));

vi.mock("./db", () => mocks);
vi.mock("./storage", () => ({ storagePut: mocks.storagePut }));

const { appRouter } = await import("./routers");

function createContext(user: TrpcContext["user"]): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const admin = {
  id: 1,
  openId: "admin-user",
  email: "admin@example.com",
  name: "Administrador",
  loginMethod: "app",
  role: "admin" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

const visitor = { ...admin, id: 2, openId: "visitor", role: "user" as const };

describe("admin content procedures", () => {
  beforeEach(() => vi.clearAllMocks());

  it("lists and mutates gallery items", async () => {
    const rows = [{ id: 1, title: "Ambiente", imageUrl: "https://example.com/a.jpg", category: "ambiente", displayOrder: 1, isActive: 1 }];
    mocks.getAllGalleryItemsAdmin.mockResolvedValueOnce(rows);
    const caller = appRouter.createCaller(createContext(admin));

    expect(await caller.admin.galleryList()).toEqual(rows);
    expect(await caller.admin.galleryCreate({ title: "Nova", imageUrl: "https://example.com/nova.jpg", category: "drinks", displayOrder: 2, isActive: 1 })).toEqual({ success: true, id: 101 });
    expect(await caller.admin.galleryUpdate({ id: 1, title: "Atualizada", isActive: 0 })).toEqual({ success: true });
    expect(await caller.admin.galleryDelete({ id: 1 })).toEqual({ success: true });

    expect(mocks.createGalleryItem).toHaveBeenCalledWith({ title: "Nova", imageUrl: "https://example.com/nova.jpg", category: "drinks", displayOrder: 2, isActive: 1 });
    expect(mocks.updateGalleryItem).toHaveBeenCalledWith(1, { title: "Atualizada", isActive: 0 });
    expect(mocks.deleteGalleryItem).toHaveBeenCalledWith(1);
  });

  it("lists and mutates menu items", async () => {
    const rows = [{ id: 2, name: "Copão", price: "R$ 18,00", category: "copoes", displayOrder: 1, isActive: 1 }];
    mocks.getAllMenuItemsAdmin.mockResolvedValueOnce(rows);
    const caller = appRouter.createCaller(createContext(admin));

    expect(await caller.admin.menuList()).toEqual(rows);
    expect(await caller.admin.menuCreate({ name: "Cerveja", price: "R$ 12,00", category: "cervejas", displayOrder: 2, isActive: 1 })).toEqual({ success: true, id: 202 });
    expect(await caller.admin.menuUpdate({ id: 2, price: "R$ 13,00" })).toEqual({ success: true });
    expect(await caller.admin.menuDelete({ id: 2 })).toEqual({ success: true });

    expect(mocks.createMenuItem).toHaveBeenCalledWith({ name: "Cerveja", price: "R$ 12,00", category: "cervejas", displayOrder: 2, isActive: 1 });
    expect(mocks.updateMenuItem).toHaveBeenCalledWith(2, { price: "R$ 13,00" });
    expect(mocks.deleteMenuItem).toHaveBeenCalledWith(2);
  });

  it("reads and writes all site settings", async () => {
    mocks.getSiteSetting.mockResolvedValueOnce("558681484273");
    mocks.getAllSiteSettings.mockResolvedValueOnce({ whatsapp_number: "558681484273" });
    const caller = appRouter.createCaller(createContext(admin));

    expect(await caller.admin.getSetting({ key: "whatsapp_number" })).toBe("558681484273");
    expect(await caller.admin.allSettings()).toEqual({ whatsapp_number: "558681484273" });
    expect(await caller.admin.setSetting({ key: "hours_weekdays", value: "Segunda a sexta, 16h às 23h" })).toEqual({ success: true });
    expect(mocks.setSiteSetting).toHaveBeenCalledWith("hours_weekdays", "Segunda a sexta, 16h às 23h");
  });

  it("uploads an image after stripping the data URL prefix", async () => {
    const caller = appRouter.createCaller(createContext(admin));
    const result = await caller.admin.uploadImage({ fileName: "foto.jpg", fileBase64: "data:image/jpeg;base64,ZmFrZQ==", contentType: "image/jpeg" });

    expect(result).toEqual({ key: "gallery/foto_abc.jpg", url: "/storage/gallery/foto_abc.jpg" });
    const [fileName, bytes, contentType] = mocks.storagePut.mock.calls[0] as [string, Buffer, string];
    expect(fileName).toBe("foto.jpg");
    expect(bytes.toString()).toBe("fake");
    expect(contentType).toBe("image/jpeg");
  });

  it("rejects all protected endpoints for non-admin users", async () => {
    const caller = appRouter.createCaller(createContext(visitor));

    await expect(caller.admin.galleryList()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.galleryCreate({ title: "x", imageUrl: "https://example.com/x.jpg", category: "ambiente" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.galleryUpdate({ id: 1, title: "x" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.galleryDelete({ id: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.menuList()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.menuCreate({ name: "x", price: "R$ 1,00", category: "comidas" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.menuUpdate({ id: 1, price: "R$ 1,00" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.menuDelete({ id: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.getSetting({ key: "x" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.allSettings()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.setSetting({ key: "x", value: "y" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.uploadImage({ fileName: "x.jpg", fileBase64: "ZmFrZQ==", contentType: "image/jpeg" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("propagates database and storage failures to the caller", async () => {
    const caller = appRouter.createCaller(createContext(admin));
    mocks.createMenuItem.mockRejectedValueOnce(new Error("menu database unavailable"));
    mocks.setSiteSetting.mockRejectedValueOnce(new Error("settings database unavailable"));
    mocks.storagePut.mockRejectedValueOnce(new Error("storage unavailable"));

    await expect(caller.admin.menuCreate({ name: "Cerveja", price: "R$ 12,00", category: "cervejas" })).rejects.toThrow("menu database unavailable");
    await expect(caller.admin.setSetting({ key: "hours_weekdays", value: "16h às 23h" })).rejects.toThrow("settings database unavailable");
    await expect(caller.admin.uploadImage({ fileName: "foto.jpg", fileBase64: "ZmFrZQ==", contentType: "image/jpeg" })).rejects.toThrow("storage unavailable");
  });
});
